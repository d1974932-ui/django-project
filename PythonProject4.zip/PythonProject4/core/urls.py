from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('profile/', views.profile, name='profile'),
    path('vacancy/<int:pk>/', views.vacancy_detail, name='vacancy_detail'),
    path('vacancy/<int:vacancy_id>/applications/', views.vacancy_applications, name='vacancy_applications'),

    # CRUD Вакансии
    path('create-vacancy/', views.create_vacancy, name='create_vacancy'),
    path('edit-vacancy/<int:pk>/', views.edit_vacancy, name='edit_vacancy'),
    path('delete-vacancy/<int:pk>/', views.delete_vacancy, name='delete_vacancy'),
    path('toggle-vacancy/<int:pk>/', views.toggle_vacancy_status, name='toggle_vacancy'),

    # CRUD Резюме
    path('create-resume/', views.create_resume, name='create_resume'),
    path('edit-resume/<int:pk>/', views.edit_resume, name='edit_resume'),
    path('delete-resume/<int:pk>/', views.delete_resume, name='delete_resume'),

    # Отклики, Статусы, Чат и Закладки
    path('apply/<int:vacancy_id>/', views.apply_vacancy, name='apply_vacancy'),
    path('quick-apply/<int:vacancy_id>/', views.quick_apply, name='quick_apply'),
    path('bookmark/<int:vacancy_id>/', views.toggle_bookmark, name='toggle_bookmark'),
    path('application/<int:application_id>/status/<str:status>/', views.update_application_status,
         name='update_application_status'),
    path('application/<int:application_id>/comment/', views.add_application_comment, name='add_application_comment'),

    path('switch-lang/<str:lang_code>/', views.switch_language, name='switch_language'),

    path('login/', auth_views.LoginView.as_view(template_name='core/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('register/', views.register, name='register'),
]