from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from .models import Vacancy, Resume, Application, Bookmark, ApplicationComment


def switch_language(request, lang_code):
    if lang_code in ['ru', 'kk']:
        request.session['django_language'] = lang_code
    next_url = request.META.get('HTTP_REFERER', '/')
    return redirect(next_url)


def home(request):
    vacancies = Vacancy.objects.filter(is_active=True).order_by('-created_at')

    bookmarked_ids = []
    if request.user.is_authenticated:
        bookmarked_ids = Bookmark.objects.filter(user=request.user).values_list('vacancy_id', flat=True)

    return render(request, 'core/home.html', {
        'vacancies': vacancies,
        'bookmarked_ids': bookmarked_ids,
    })


@login_required
def profile(request):
    user_resumes = Resume.objects.filter(user=request.user)
    user_vacancies = Vacancy.objects.filter(employer=request.user).order_by('-created_at')
    user_applications = Application.objects.filter(applicant=request.user).prefetch_related('comments')
    received_applications = Application.objects.filter(vacancy__employer=request.user).select_related('vacancy',
                                                                                                      'applicant',
                                                                                                      'resume').prefetch_related(
        'comments')

    bookmarked_vacancies = Vacancy.objects.filter(bookmark__user=request.user, is_active=True)

    viewed_ids = request.session.get('viewed_vacancies', [])
    viewed_vacancies = Vacancy.objects.filter(id__in=viewed_ids) if viewed_ids else []

    return render(request, 'core/profile.html', {
        'resumes': user_resumes,
        'vacancies': user_vacancies,
        'applications': user_applications,
        'received_applications': received_applications,
        'viewed_vacancies': viewed_vacancies,
        'bookmarked_vacancies': bookmarked_vacancies,
    })


def vacancy_detail(request, pk):
    vacancy = get_object_or_404(Vacancy, pk=pk)

    viewed = request.session.get('viewed_vacancies', [])
    if pk not in viewed:
        viewed.insert(0, pk)
        request.session['viewed_vacancies'] = viewed[:10]

    resumes = []
    is_bookmarked = False
    if request.user.is_authenticated:
        resumes = Resume.objects.filter(user=request.user)
        is_bookmarked = Bookmark.objects.filter(user=request.user, vacancy=vacancy).exists()

    return render(request, 'core/vacancy_detail.html', {
        'vacancy': vacancy,
        'resumes': resumes,
        'is_bookmarked': is_bookmarked,
    })


@login_required
def vacancy_applications(request, vacancy_id):
    vacancy = get_object_or_404(Vacancy, pk=vacancy_id, employer=request.user)
    applications = Application.objects.filter(vacancy=vacancy).select_related('applicant', 'resume')

    return render(request, 'core/vacancy_applications.html', {
        'vacancy': vacancy,
        'applications': applications
    })


@login_required
def create_vacancy(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        company_name = request.POST.get('company_name')
        description = request.POST.get('description')
        salary = request.POST.get('salary')
        location = request.POST.get('location')

        Vacancy.objects.create(
            employer=request.user,
            title=title,
            company_name=company_name,
            description=description,
            salary=salary,
            location=location
        )
        return redirect('profile')
    return render(request, 'core/create_vacancy.html')


@login_required
def edit_vacancy(request, pk):
    vacancy = get_object_or_404(Vacancy, pk=pk, employer=request.user)
    if request.method == 'POST':
        vacancy.title = request.POST.get('title')
        vacancy.company_name = request.POST.get('company_name')
        vacancy.description = request.POST.get('description')
        vacancy.salary = request.POST.get('salary')
        vacancy.location = request.POST.get('location')
        vacancy.save()
        return redirect('profile')
    return render(request, 'core/edit_vacancy.html', {'vacancy': vacancy})


@login_required
def delete_vacancy(request, pk):
    vacancy = get_object_or_404(Vacancy, pk=pk, employer=request.user)
    if request.method == 'POST':
        vacancy.delete()
        return redirect('profile')
    return render(request, 'core/delete_confirm.html', {'item': vacancy, 'type': 'vacancy'})


@login_required
def toggle_vacancy_status(request, pk):
    vacancy = get_object_or_404(Vacancy, pk=pk, employer=request.user)
    vacancy.is_active = not vacancy.is_active
    vacancy.save()
    return redirect('profile')


@login_required
def create_resume(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        skills = request.POST.get('skills')
        experience = request.POST.get('experience')
        education = request.POST.get('education')

        Resume.objects.create(
            user=request.user,
            title=title,
            skills=skills,
            experience=experience,
            education=education
        )
        return redirect('profile')
    return render(request, 'core/create_resume.html')


@login_required
def edit_resume(request, pk):
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    if request.method == 'POST':
        resume.title = request.POST.get('title')
        resume.skills = request.POST.get('skills')
        resume.experience = request.POST.get('experience')
        resume.education = request.POST.get('education')
        resume.save()
        return redirect('profile')
    return render(request, 'core/edit_resume.html', {'resume': resume})


@login_required
def delete_resume(request, pk):
    resume = get_object_or_404(Resume, pk=pk, user=request.user)
    if request.method == 'POST':
        resume.delete()
        return redirect('profile')
    return render(request, 'core/delete_confirm.html', {'item': resume, 'type': 'resume'})


@login_required
def apply_vacancy(request, vacancy_id):
    if request.method == 'POST':
        vacancy = get_object_or_404(Vacancy, pk=vacancy_id)
        resume_id = request.POST.get('resume_id')
        cover_letter = request.POST.get('cover_letter', '')
        resume = get_object_or_404(Resume, pk=resume_id, user=request.user)

        Application.objects.create(
            vacancy=vacancy,
            applicant=request.user,
            resume=resume,
            cover_letter=cover_letter
        )
        return redirect('profile')


@login_required
def quick_apply(request, vacancy_id):
    vacancy = get_object_or_404(Vacancy, pk=vacancy_id, is_active=True)
    user_resume = Resume.objects.filter(user=request.user).order_by('-created_at').first()

    if not user_resume:
        return redirect('create_resume')

    already_applied = Application.objects.filter(vacancy=vacancy, applicant=request.user).exists()
    if not already_applied:
        Application.objects.create(
            vacancy=vacancy,
            applicant=request.user,
            resume=user_resume,
            cover_letter="Быстрый отклик в 1 клик"
        )
    return redirect('profile')


@login_required
def toggle_bookmark(request, vacancy_id):
    vacancy = get_object_or_404(Vacancy, pk=vacancy_id)
    bookmark, created = Bookmark.objects.get_or_create(user=request.user, vacancy=vacancy)
    if not created:
        bookmark.delete()
    next_url = request.META.get('HTTP_REFERER', '/')
    return redirect(next_url)


@login_required
def update_application_status(request, application_id, status):
    application = get_object_or_404(Application, pk=application_id)
    if request.user == application.vacancy.employer or request.user == application.applicant:
        if status in ['accepted', 'rejected', 'pending']:
            application.status = status
            application.save()
    next_url = request.META.get('HTTP_REFERER', '/profile/')
    return redirect(next_url)


@login_required
def add_application_comment(request, application_id):
    application = get_object_or_404(Application, pk=application_id)
    if request.user == application.applicant or request.user == application.vacancy.employer:
        if request.method == 'POST':
            text = request.POST.get('text', '').strip()
            if text:
                ApplicationComment.objects.create(
                    application=application,
                    author=request.user,
                    text=text
                )
    next_url = request.META.get('HTTP_REFERER', 'profile')
    return redirect(next_url)


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'core/register.html', {'form': form})