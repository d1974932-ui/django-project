from django.contrib import admin
from .models import Vacancy, Resume, Application, Bookmark, ApplicationComment

@admin.register(Vacancy)
class VacancyAdmin(admin.ModelAdmin):
    list_display = ('title', 'company_name', 'salary', 'location', 'is_active', 'created_at')
    list_filter = ('is_active', 'location', 'created_at')
    search_fields = ('title', 'company_name', 'description')

@admin.register(Resume)
class ResumeAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('title', 'skills', 'experience')

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ('vacancy', 'applicant', 'resume', 'status', 'applied_at')
    list_filter = ('status', 'applied_at')
    search_fields = ('vacancy__title', 'applicant__username')

@admin.register(ApplicationComment)
class ApplicationCommentAdmin(admin.ModelAdmin):
    list_display = ('application', 'author', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('text', 'author__username')

@admin.register(Bookmark)
class BookmarkAdmin(admin.ModelAdmin):
    list_display = ('user', 'vacancy', 'created_at')
    list_filter = ('created_at',)